package com.controller;

public class Trainer implements TrainerInterface{
    public void teach(){
        System.out.println("teaching");
    }
}
