package com.controller;

public interface TrainerInterface {
    void teach();
}
