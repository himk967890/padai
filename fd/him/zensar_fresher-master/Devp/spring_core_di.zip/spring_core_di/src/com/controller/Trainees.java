package com.controller;

public class Trainees {


    TrainerInterface tt;
    public void setTt(TrainerInterface tt){ //ADAPTER
        this.tt=tt;
    }

    public void use(){
        tt.teach();
    }
    public static void main(String ag[]){
        TrainerInterface t1=new Trainer();

        Trainees t2=new Trainees();
        t2.setTt(t1);  //DI
        t2.use();

    }
}
